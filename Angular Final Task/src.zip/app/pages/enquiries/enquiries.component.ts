import { Component } from '@angular/core';
import { enquiry } from '../../model/enquiry';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-enquiries',
  templateUrl: './enquiries.component.html',
  styleUrl: './enquiries.component.css'
})
export class EnquiriesComponent {
  enquirylist: enquiry[] = [];

  serviceTypes: string[] = [
     'All',
     "Harry Potter",
  "The Lord of the Rings",
  "The Alchemist",
  "Sherlock Holmes",
  "To Kill a Mockingbird",
  "1984",
  "The Great Gatsby"
    ];

    selected:string = 'All'
    constructor(private api:ApiService){

    }
  
    ngOnInit(){ 
       this.api.getEnquiries().subscribe({
         next: (response:enquiry[]) => {
           this.enquirylist = response;
         },
         error: (error) => {
           console.log("Error while fetching enquiries", error);
         }
    })
  }
  
}
