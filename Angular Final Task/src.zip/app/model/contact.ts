export interface Contact {
    name: string;
    address: string;
    city: string;
    pin: string;
    mobile: string;
    email: string;
    image: string;
    id: string;
}