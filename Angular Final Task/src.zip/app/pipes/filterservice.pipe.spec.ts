import { FilterservicePipe } from './filterservice.pipe';

describe('FilterservicePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterservicePipe();
    expect(pipe).toBeTruthy();
  });
});
